<?php


  ?>

<!DOCTYPE html>
<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Quicksand&display=swap" rel="stylesheet">
<script src="jquery.min.js"></script>

<script>

function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}

</script>

</head>
<style>
#wrapper {
    max-width: 100%;
    margin-left: 5vw;    /* center the page */
    margin-bottom: 70px;
    font-family: 'Open Sans', sans-serif;
    text-align:center;
}

#content {
    display: inline-block;
    text-align: center;
    background-color: #fff;
    font-family: 'Open Sans', sans-serif;
    padding: 20px 30px;
    width: 75%;                /* fill up the entire div */
}

/* begin table styles */
table {
    border-collapse: collapse;
    width: 100%;
}

table a {
    color: #000;
}

table a:hover {
    color:#373737;
    text-decoration: none;
}

th {
    background-color: #B40E1F;
    color: #F0F0F0;
}

td {
    padding: 5px;
}

/* Begin font styles */
h1{
    font-family: 'Open Sans', sans-serif;
    color: black;
}



</style>

<body>


  <div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->

  <div id="main">
    <header class="header-bar">
    <button class="openbtn" onclick="openNav()">☰</button>
    <span class="page-title">SCHEDULE</span>
    <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
  </header><!-- header-bar -->
  </div><!-- main -->

  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="EnterSchedule.php">edit weekly schedule</a>
    <a href="#">manage notifications</a>
    <a href="#">account settings</a>
  </div><!-- mySidebar sidebar -->


  <div id ="wrapper">
    <div id="content">
    <h2>Enter Your Schedule Today</h2>

            <form action="enteringSchedule.php" method="post" text-align="center">
                

				<label>Start</label> <br> 
                  <input type="time" name="monStart" value="09:00:00"><br>
                <label>End</label> <br> 
                  <input type="time" name="monEnd" value="19:00:00"><br>
                <br>
                <input type="submit" value="Submit">
            </form>    
    </div>
  </div>
</body>
<script>
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>

</html>