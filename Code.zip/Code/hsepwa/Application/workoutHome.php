<?php
  require 'connect.php'; 
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="workoutHome.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Quicksand&display=swap" rel="stylesheet">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">

<style>
body,html {
    height: 100%;
    margin: 0;
    font-family: 'Open Sans', sans-serif;
    width:100%;
    overflow-x: hidden;
  }
  
  .hero-image {
    background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("workoutHome.jpg");
    height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
  }
  
  .hero-text {
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-family: 'Open Sans', sans-serif;
  }
  
  .hero-text button {
    border: none;
    outline: 0;
    display: inline-block;
    padding: 10px 25px;
    color: black;
    background-color: #ddd;
    text-align: center;
    cursor: pointer;
  }
  
  .hero-text button:hover {
    background-color: #555;
    color: white;
  }
  
  .buttonload {
    background-color: #4CAF50; 
    color: white; 
    padding: 12px 16px; 
    font-size: 16px;
    position:flex;    
  }
  .custom-select {
    background-color:A8D8E6;
  }
  
  .homeLink{
    background-color: white;
    color: black;
    border: 2px solid #4CAF50;
  }
  
  </style>
</head>
<body>


<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a class="active" href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->

<div id="main">
  <header class="header-bar">
  <button class="openbtn" onclick="openNav()">☰</button>
  <span class="page-title">WORKOUTS</span>
  <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
</header><!-- header-bar -->
</div><!-- main -->

<div id="mySidebar" class="sidebar">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
  <a href="EnterSchedule.php">edit weekly schedule</a>
  <a href="#">manage notifications</a>
  <a href="#">account settings</a>
</div><!-- mySidebar sidebar -->

<div class="hero-image" >
  <div class="hero-text">
    <h1>Minding Yourself <br> Workout Series</h1>

    <div class="custom-select" style="width:400px;text-align:center">
       <br>
 <select name = 'test' onchange = 'gotourl(this.value)' >\
    <option value="0">Select Workout</option>
    <option value="2">Desk Stretches</option>
    <option value="3">Strengthening Exercises for the Whole Body</option>
    <option value="4">Walk Your Way to Fitness</option>
  </select>     
</div>

</div>

</div>

<script>
function gotourl(id)
{
  if(id == 2)
{
location.href='deskStretches.php';
}else if(id == 3)
{
location.href='wholeBody.php';
}else if(id == 4)
{
location.href='walkYourWay.php';
}
}


function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}

</script>

</body>
</html>