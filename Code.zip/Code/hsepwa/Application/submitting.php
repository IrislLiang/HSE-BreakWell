<?php
  require 'connect.php'; 
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">

<style>
body,html {
    height: 100%;
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    width:100%;
    overflow-x: hidden;
  }
  
  .hero-image {
    background-color: green;
    height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative;
  }
  
  .hero-text {
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
  }
  
  .hero-text button {
    border: none;
    outline: 0;
    display: inline-block;
    padding: 10px 25px;
    color: black;
    background-color: #ddd;
    text-align: center;
    cursor: pointer;
  }
  
  .hero-text button:hover {
    background-color: #555;
    color: white;
  }
  
  
  
  </style>
</head>
<body>


<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a class="active" href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->

<header class="desktopHeader">
<div class="pageTitle"><span>Scheduler</span></div>
<nav class="navBar">
    <a href="feedback.php">Feedback</a>
    <a href="recipeshome.html">Recipe</a>
    <a href="workouthome`.html">Workout</a>
    <a class="active" href="EnterSchedule.php">Scheduler</a>
    <a href="dashboard">Home</a>
</nav><!-- navBar -->
</header>

<div id="main">
  <header class="header-bar">
  <button class="openbtn" onclick="openNav()">☰</button>
  <span class="page-title">Workout Library</span>
</header><!-- header-bar -->
</div><!-- main -->

<div id="mySidebar" class="sidebar">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
  <a href="EnterSchedule.php">Weekly Schedule</a>
  <a href="#">Notifications</a>
  <a href="#">Account</a>
  <a href="#">Settings</a>
</div><!-- mySidebar sidebar -->

<div class="hero-image" >
  <div class="hero-text">
    <h1 style="font-size:40px; ">Submitting Your Feedback</h1>
      
</div>  
   

</div>

</div>

<script>
// Simulate an HTTP redirect:
window.location.replace("feedback.php");
</script>

</body>
</html>