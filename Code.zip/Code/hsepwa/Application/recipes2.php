<!DOCTYPE html>
<html>
  <head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">  

<style>
#content {
    display: inline-block;
    text-align: left;
    background-color: #fff;
    font-family: 'Open Sans', sans-serif;
    padding: 20px;
    width: 80%;               /* fill up the entire div */
    margin-bottom: 70px;
}
</style>
  </head>

<body>
      
<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a class="active" href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->


  <div id="main">
    <header class="header-bar">
    <button class="openbtn" onclick="openNav()">☰</button>
    <span class="page-title">RECIPES</span>
    <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
  </header><!-- header-bar -->
</div><!-- main  -->

  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="EnterSchedule.php">edit weekly schedule</a>
    <a href="#">manage notifications</a>
    <a href="#">account settings</a>
  </div><!-- mySidebar sidebar -->
  
<div id="content" style="position:flex; flex-direction:row">
<h1 style="text-align:center">Spiced Chips with Chicken</h1>
  <h2 style="text-align:center"><i>Omit chicken for vegetarian version</i></h2>
  <hr>
  <h2>Ingredients - Serves 2 Adults</h2>
    <p>
    <ul >
      <li>2 medium chicken breasts cut into strips</li>
      <li>80g breadcrumbs</li>
      <li>½ teaspoon of cumin</li>
      <li>2 eggs</li>
      <li>1 tablespoon and 1 teaspoon of vegetable oil</li>
      <li>3 medium potatoes</li>
      <li>1 medium onion</li>
      <li>2 sprigs of rosemary</li>
      <li>1 tablespoon of chinese 5 spice</li>
      <li>½ teaspoon of chilli powder</li>
      <li>Salt to garnish</li>
      <li>Red and green chilli to garnish (optional) </li>
    </ul>
    </p>
     <h2>Method</h2>
    <p>
    <ol>
      <li>For the chicken, place the strips into beaten egg. In a bowl, mix the cumin and breadcrumbs. Preheat the oven to 200°C/ 400°F/ Gas Mark 6.</li>
      <li>Place the chicken into the breadcrumbs mixed with cumin until fully coated and place onto a baking tray with 1 teaspoon of vegetable oil. If you find they aren't fully coated, go back and dip again into the egg and then back into the bread mix. Place into the oven and bake for 20-30 minutes.</li>
      <li>Remember to wash your hands with warm soapy water after handling raw chicken.</li>
      <li>For the chips, slice them up to whatever thickness you like and bake with the rosemary, sliced onion and tablespoon of vegetable oil for 35/40 minutes on a baking tray. If your tray isn't non-stick, use some grease proof or parchment paper. </li>
      <li>Mix the spice ingredients together in a small bowl. Combine both the chicken and chips together and then from a height sprinkle over the spice mix coating both the chicken and chips.</li>
    </ol>
    </p>
    <img src="dish2.png" alt="picture" height="500px" width="300px" style="padding-left:50px">
    </div>
  </body>
<script>
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>

</html>