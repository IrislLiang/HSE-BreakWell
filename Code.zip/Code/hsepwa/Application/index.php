<?php

include ('connect.php');



	// connect to the database
	$conn = mysqli_connect('81.16.28.205', 'u984442499_hsedbadmin', 'Jeremiah.123', 'u984442499_hse_database');


?>
<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Quicksand&display=swap" rel="stylesheet">

<script>
  function openLogin() {
    location.href='login.php'; 
  }

  if ("serviceWorker" in navigator) {
  // register service worker
  navigator.serviceWorker.register("service-worker.js");
}

</script>
<style>
    
/* Styling for login form*/
    input, select, textarea {
      width: 100%;
      padding: 12px;
      box-sizing: border-box;
      margin-top: 6px; 
      margin-bottom: 16px; 
      resize: vertical;
    }

    .container {
      border-radius: 5px;
      background-color: #00B0E0;
      align-content: center;
      font-family: 'Quicksand', sans-serif;
      width:100%;
    }    
</style>

<body style="background-color:#00B0E0">

<div id="main">
    <!-- Begin contact form, code from W3Schools.com -->
    <div class="container">
    
    <img src="HSE_Logo_White.png" alt="Health Service Executive Ireland" style="width:100%"></a>
    <br>
    <br>

        
					
            <?php
            // If the session is logged in, display username
            if(isset($_SESSION['logged_in'])) {
            header('dashboard.php');
						
            // If the session is not logged in ask to login
             }else{
              echo "<h2>You Are Not Logged In</h2>";
              echo "<br><h2>Login to Continue</h2>";
              echo '<br><br> <button class="openbtn" style="width:50%,align:center" onclick="openLogin()">LogIn</button> ';
            }
            ?> 
    <br>
    </div>

</div>
</body>

</html>