<?php 


// call connection 

define('DB_SERVER', '81.16.28.205');
define('DB_USERNAME', 'u984442499_hsedbadmin');
define('DB_PASSWORD', 'Jeremiah.123');
define('DB_NAME', 'u984442499_hse_database');

/* Attempt to connect to MySQL database */
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);


          $workout = $_POST['workout'];
          $meditation = $_POST['meditation'];
          $recipe = $_POST['recipe'];
          $workoutTime = $_POST['workoutTime'];
          $meditationTime = $_POST['breakTime'];
          $recipeTime = $_POST['mealTime'];


          $username = "u984442499_hsedbadmin";
          $password = "Jeremiah.123";
          $database = "u984442499_hse_database";
          $conn = new mysqli("81.16.28.205", $username, $password, $database);
          

          $user_id = 1;
          
          
                            $query = "UPDATE events 
                            
                            SET workoutActivity= '$workout',mealActivity = '$recipe', breakActivity = '$meditation',

                            workoutTime= '$workoutTime',mealTime = '$recipeTime', breakTime = '$meditationTime'

                            WHERE (userId=1)";  //hardcoded for prototype
          
                            $result = mysqli_query($conn, $query);

                            

                            if (!$result) {    
                                die("Couldn't enter data: ".$conn->error);
                            } else {
                            
                            header('location: editBreaks.php');
                            }

                            $mysqli -> close();
                      
          
		    ?>