<?php 
include('connect.php');
$feedback_details;
	// connect to the database
	$conn = mysqli_connect('81.16.28.205', 'u984442499_hsedbadmin', 'Jeremiah.123', 'u984442499_hse_database');

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Quicksand&display=swap" rel="stylesheet">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">

<title>Edit Breaks</title>

<style>

#addBreak {
  background-color: #CDD0D4;
  color: #000;
  padding:10px;
}
#addWorkout {
  background-color: #C2C5C8;
  color: #000;
  padding:10px;
}

#addRecipe {
  background-color: #A8ABAD;
  color: #000;
  padding:10px;
}

#wrapper {
    max-width: 100%;
    margin-left: 10px;    /* center the page */
    margin-bottom: 70px;
}

#content {
    display: inline-block;
    padding:10px;
    text-align: center;
    background-color: #fff;
    font-family: 'Open Sans', sans-serif;
    max-width: 100%;               /* fill up the entire div */
}
	
.container {
      border-radius: 5px;
      background-color: #fff;
      padding: 20px;
	}

/* begin table styles */
table {
    border-collapse: collapse;
    max-width: 100%;
    text-align: left;
    margin:0 auto;
}

table a {
    color: #000;
}

table a:hover {
    color:#00B0E0;
    text-decoration: none;
}

th {
    background-color: #fff;
    color: #000;
    text-align:center;
    font-size:20px;
}

td {
    padding: 5px;
    text-align:center;
}
</style>
</head>
<body>


<div class="icon-bar">
  <a class="active" href="dashboard.php"><i class="fa fa-home"></i></a>
  <a href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->



  <div id="main">
    <header class="header-bar">
    <button class="openbtn" onclick="openNav()">☰</button>
    <span class="page-title">EDIT BREAKS</span>
    <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
  </header><!-- header-bar -->
  </div><!-- main  -->

  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="EnterSchedule.php">edit weekly schedule</a>
    <a href="#">manage notifications</a>
    <a href="#">account settings</a>
  </div><!-- mySidebar sidebar -->


<div id="wrapper">  

  <div id="content">
  <h2 style="text-align:center">
  <?php
            // Display date
            {
            echo date("l jS \of F Y")."<br>";
            
          $query = "SELECT * FROM events where userId=1 and weekdayId=4"; //hardcoded for prototype
          
          $result = mysqli_query($conn, $query);
          while($row = mysqli_fetch_assoc($result)) {
          
          $startTime = $row['eventStart'];
          echo '<br> Shift Starts at '. "$startTime".'<br>';
          $endTime = $row['eventEnd'];
					echo '<br> Shift ends at '. "$endTime".'<br>';
            }
          }  
            ?>
    </h2>
     <br> 
		<table style = "background-color: white; padding: 10px; width: 100%">
        <th>Time</th>
				<th>Activity</th>
        
        <?php 
         require 'connection.php';
					$query = "SELECT * FROM events where userId=1 and weekdayId=4"; //hardcoded for prototype
					$result = mysqli_query($conn, $query);
          
          while ($row = mysqli_fetch_assoc($result)) {
  
          echo '<tr>';
					$BreakTime = $row['breakTime'];
          echo '<td>'. "$BreakTime".'</td>';
					$BreakActivity = $row['breakActivity'];
					echo '<td>'. "$BreakActivity".'</td>';
                    echo '</tr>';

                    echo '<tr>';
					$workoutTime = $row['workoutTime'];
          echo '<td>'. "$workoutTime".'</td>';
					$workoutActivity = $row['workoutActivity'];
					echo '<td>'. "$workoutActivity".'</td>';
                    echo '</tr>';

                    echo '<tr>';
					$mealTime = $row['mealTime'];
          echo '<td>'. "$mealTime".'</td>';
					$mealActivity = $row['mealActivity'];
					echo '<td>'. "$mealActivity".'</td>';
                    echo '</tr>';

					
                  }
		    ?>
		</table>
    <br>

<div class="container">

<form action="editingBreaks.php" method="post">
<h2>Add a Break</h2>
            <div id="addBreak">

											<label> Time </label> <br>  
											<input type="time" name="breakTime"> <br>

											<label>Break Activity</label><br>
											<select name ='meditation' style="width:75%">
                      <option value="0">Select Break</option>
                      <option value="Stretch Break">Stretch Break</option>
                      <option value="Breath & Body Mindfulness Practice">Breath & Body Mindfulness Practice</option>
                      <option value="Loving Kindness Meditation">Loving Kindness Meditation</option>
                      <option value="How to Stay Motivated">How to Stay Motivated</option>
                      </select> 
                    <br>
                <br>
              </div>
						<h2>Add a Workout</h2>
            <div id="addWorkout">

											<label> Time </label> <br>  
											<input type="time" name="workoutTime"> <br>

											<label>Workout </label><br>
											<select name = 'workout' style="width:75%">
                      <option value="0">Select Workout</option>
                      <option value="Desk Stretches">Desk Stretches</option>
                      <option value="Strengthening Exercises for the Whole Body">Strengthening Exercises for the Whole Body</option>
                      <option value="Walk Your Way to Fitness">Walk Your Way to Fitness</option>
                      </select> 
                    <br>
                <br>
                </div>
            <h2>Add a Meal</h2>
            <div id="addRecipe">

											<label> Time </label> <br>  
											<input type="time" name="mealTime"> <br>

											<label>Recipe </label><br>
											<select name = 'recipe' style="width:75%">
                      <option value="0">Select Recipe</option>
                      <option value="Spinach and Mandarin Salad">Spinach and Mandarin Salad</option>
                      <option value="Spiced Chips">Spiced Chips</option>
                      <option value="Pepperoni Pizza">Pepperoni Pizza</option>
                      <option value="Bean Burrito">Bean Burrito</option>
                      </select> 
                    <br>
                    <br>
                </div> 	
                <br>
              <input type="submit" value="Submit"> <br>
            </div>
        </form>
  </div>
</div>  
</body>
<script>
  function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}

</script>
</html>