<!DOCTYPE html>
<html>
  <head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">  

<style>
#content {
    display: inline-block;
    text-align: left;
    background-color: #fff;
    font-family: 'Open Sans', sans-serif;
    padding: 20px;
    width: 80%;               /* fill up the entire div */
    margin-bottom: 70px;
}
</style>
  </head>

<body>
      
<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a class="active" href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->


  <div id="main">
    <header class="header-bar">
    <button class="openbtn" onclick="openNav()">☰</button>
    <span class="page-title">RECIPES</span>
    <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
  </header><!-- header-bar -->
</div><!-- main  -->

  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="EnterSchedule.php">edit weekly schedule</a>
    <a href="#">manage notifications</a>
    <a href="#">account settings</a>
  </div><!-- mySidebar sidebar -->
  
<div id="content" style="position:flex; flex-direction:row">
<h1 style="text-align:center">Spinach & Mandarin Salad</h1>
  <h2 style="text-align:center"><i>Suitable for vegetarians</i></h2>
  <hr>
  <h2>Ingredients - Serves 6 Adults</h2>
    <p>
    <ul >
      <li>500g / 18 oz. of fresh spinach leaves</li>
      <li>1 medium red onion, sliced</li>
      <li>1 x 310g / 11 oz. can of mandarin oranges</li>
      <li>60ml / 2 fl oz. of red wine vinegar</li>
      <li>60ml / 2 fl oz. of water</li>
      <li>3 tablespoons of olive oil</li>
      <li>2 tablespoons of honey</li>
      <li>60g / 2 oz. of sliced almonds, toasted</li>
    </ul>
    </p>
     <h2>Method</h2>
    <p>
    <ol>
      <li>Fresh spinach is notoriously dirty. Bacteria such as E. coli and Listeria are commonly found in soil, so carefully wash the spinach by first soaking the leaves in a clean sink filled with cold water</li>
      <li>After swishing the leaves around in the water, take out only one or two pieces at a time, making sure that there is no remaining soil clinging them</li>
      <li>Tear the leaves into bite-size pieces</li>
      <li>Combine the spinach and mandarin oranges in a salad bowl</li>
      <li>In a small mixing bowl, combine the vinegar, water, olive oil and honey</li>
      <li>Beat with a whisk and mix into spinach and oranges</li>
      <li>Fry the onions in vegetable oil until they are brown and soft, then mix them into the rest of the salad while still hot</li>
      <li>Toast the almonds and mix them into the salad while still hot</li>
    </ol>
    </p>
    <img src="dish1.png" alt="picture" height="500px" width="300px" style="padding-left:50px">
    </div>
  </body>
<script>
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>

</html>