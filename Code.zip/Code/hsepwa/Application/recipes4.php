<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="manifest" href="manifest.json">
    <link rel="stylesheet" href="css/style.css">  
  </head>

  <style>

    #content {
      display: inline-block;
      text-align: left;
      background-color: #fff;
      font-family: 'Open Sans', sans-serif;
      padding: 20px;
      width: 80%;               /* fill up the entire div */
      margin-bottom: 70px;
    }
  </style>
  <body>
      
<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a class="active" href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->


  <div id="main">
    <header class="header-bar">
    <button class="openbtn" onclick="openNav()">☰</button>
    <span class="page-title">Recipe Library</span>
  </header><!-- header-bar -->
</div><!-- main  -->

  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="EnterSchedule.php">Weekly Schedule</a>
    <a href="#">Notifications</a>
    <a href="#">Account</a>
    <a href="#">Settings</a>
  </div><!-- mySidebar sidebar -->


    <div class="content" style="position:flex; flex-direction:row">
    <h1>
     &#12288; Mexican bean burrito
    </h1>    
    <h2>
      &#12288; &#12288; <u>Healthy takeaway at home</u>
    </h2>

  <h3 class="ingredients" style="padding-left:90px;">
    &#12288; &#12288;&#12288;Ingredients - Serves 4 Adults
    </h3>
    <ul >
      <li>1 medium onion</li>
      <li>1 medium red pepper</li>
      <li>60g of reduced fat cheddar cheese</li>
      <li>1 tablespoon of olive oil</li>
      <li>1 clove of garlic</li>
      <li>1 teaspoon of chilli powder</li>
      <li>1 teaspoon of tomato puree</li>
      <li>400g of kidney beans</li>
      <li>400g of tinned tomatoes</li>
      <li>4 large tortillas</li>
      <li>2 handfuls of salad leaves</li>
    </ul>
    <img src="dish4.png" alt="picture" height="500px" width="300px" style="padding-left:50px">
     <h3 class="methods" style="padding-left:90px">
    &#12288; &#12288;&#12288;Method
    </h3>
    <ol>
     <li>Preheat the oven to 180°C/350°F/ gas 4. Peel and finely slice the onion, then deseed and slice up the pepper. Coarsely grate the cheese.</li>
      <li>Heat half the oil in a frying pan over a medium-low heat and gently fry the onion for 10 minutes, or until softened.</li>
      <li>Peel and crush the garlic, then add to the pan along with the chilli powder.</li>
      <li>Add the tomato purée and the tomatoes, breaking them up with a spoon as you go, then drain and add the kidney beans.</li>
      <li>Cook for 10 minutes, or until slightly reduced, then season to taste with sea salt and black pepper.</li>
      <li>In a separate pan, fry the pepper in the rest of the oil until starting to soften, then set aside.</li>
      <li>Divide the filling mixture in half, then blitz one half with a stick blender to form a bean paste – if you don’t have a stick blender, mash with a potato masher.</li>
      <li>Spread the tortillas with the warm bean paste, then add a serving spoon of the filling and a spoonful of red pepper, and sprinkle with cheese and some salad leaves. Roll up the tortillas and place on greased baking tins.</li>
      <li>Bake for 5 to 10 minutes, or until golden and warmed through.</li>
    </ol>
    
    </div>
  </body>
<script>
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>
</html>