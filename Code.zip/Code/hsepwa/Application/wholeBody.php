<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="manifest" href="manifest.json">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Quicksand&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">  
<style>
  .container {
    display: inline-block;
    text-align: left;
    background-color: #fff;
    font-family: 'Open Sans', sans-serif;
    padding: 20px;
}

/* Then style the iframe to fit in the container div with full height and width */
.responsive-iframe {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
}
  </style>
  </head>
  <body>
     
<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a class="active" href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->

<div id="main">
  <header class="header-bar">
  <button class="openbtn" onclick="openNav()">☰</button>
  <span class="page-title">WORKOUTS</span>
  <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
</header><!-- header-bar -->
</div><!-- main -->

<div id="mySidebar" class="sidebar">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
  <a href="#">edit weekly schedule</a>
  <a href="#">manage notifications</a>
  <a href="#">account settings</a>
</div><!-- mySidebar sidebar -->

<div class="container">
  <select name = 'test' onchange = 'gotourl(this.value)' style="width:75%">
    <option value="0">Select Workout</option>
    <option value="2">Desk Stretches</option>
    <option value="3">Strengthening Exercises for the Whole Body</option>
    <option value="4">Walk Your Way to Fitness</option>
  </select>

   <h1>Strengthening Exercise for the Whole Body</h1><br>
   <iframe width="100%" src="https://www.youtube.com/embed/5Y9lA4uaftg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
    </iframe>
     <h2>Disclaimer</h2>
     <p style="font-size:0.5em">
     <i>To avoid any injury or harm, check your health with your doctor before exercising. 
     By performing any fitness exercises without supervision like with this video, 
     you are performing them at your own risk. See a fitness professional for advice on your exercise form. 
     Pamela Reif will not be responsible or liable for any injury or harm you sustain as a result of this video.
    </i> 
    </p>

</div>  
  </body>
 <script>
function gotourl(id)
{
  if(id == 2)
{
location.href='deskStretches.php';
}else if(id == 3)
{
location.href='wholeBody.php';
}else if(id == 4)
{
location.href='walkYourWay.php';
}
}

function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}

</script>
</html>