/**
 * Copyright 2020 HSE All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

// DO NOT EDIT THIS GENERATED OUTPUT DIRECTLY!
// This file should be overwritten as part of your build process.

// Alternatively, it's possible to make changes to the underlying template file and then use that as the
// new base for generating output

// If you go that route, make sure that whenever you update your sw-precache dependency, you reconcile any
// changes made to this original template file with your modified copy.

// This generated service worker JavaScript will precache your site's resources.
// The code needs to be saved in a .js file at the top-level of your site, and registered
// from your pages in order to be used.

/* eslint-env worker, serviceworker */
/* eslint-disable indent, no-unused-vars, no-multiple-empty-lines, max-nested-callbacks, space-before-function-paren, quotes, comma-spacing */

'use strict';

var precacheConfig = [["Check.php","bd20a021dbf4883f60e27ef9632865f7"],["Dashboard.php","8714cd2f95f994c36fd734bc9e8def05"],["EditBreaks.php","eb88c6814b2d6c33dfdcc3556709260f"],["EnterSchedule.php","b3ca47faa333146df053bb77162602fa"],["HSE_Logo_White.png","cec46540e7f8ec5fc29fb61684932947"],["HSE_Logo_White_Small.png","0801b9dc025eb661ab3d9a6cf3195789"],["LOGO.png","a1d7e272ed4d6683f960a26ec4c6882e"],["Login.php","a25becc0201074b6a933fd786963ecc3"],["Mexican-Bean-Burrito_1.jpg","6466fa68c53829187542c807af994fae"],["Motivated.php","19bd47cd33f20360060fccec07b54856"],["Pepperoni-Pizza_1.jpg","288c8e5de0caebd5cd6143237f8fa85c"],["Readme.md","baf9ddfa5421f6bc62657a6bdf596835"],["Spice-Bag_1.jpg","1565ea83d94c3515dd47f8a9cf704599"],["Spinachsalad240x185.jpg","067d5eb4bc016a066c95d3d1b0c1784f"],["breathingSpace.php","ec8abed56f2ab1501cbd4c4ae0d0322d"],["connect.php","3353d94365e2f9c3fc19e4564618a5c6"],["connection.php","3353d94365e2f9c3fc19e4564618a5c6"],["css/site.css","f6a6c093a2cedc9dfd57f66fa9a1c72f"],["css/style.css","282ef030e0a66c1a72ceda2ed42c7c2d"],["deskStretches.php","60844de37e8da3ea8561d57b2e46943c"],["dish1.png","f607b0bb6469112901202a67d2df4d68"],["dish2.png","3e3d199beeb687ea7f79e140173dbf87"],["dish3.png","2acca299142b631597c4fbd391966218"],["dish4.png","9295fb9d1af0da1339dc94ed8c46c9b7"],["feedback.php","ed637690ad50dcbbc8efc4de2214d076"],["fonts/segoeuil.ttf","11fd79bcf7943677aa0a7217a8e19470"],["functions.php","00daf42757f021da1a1f6a2254370674"],["img/cloneWhite.svg","159afe3641b3c612502d04aceb0c48fc"],["img/deployWhite.svg","54e086853a5c6c86b690a5ac254109f2"],["img/lightbulbWhite.svg","c96c6df7c8ffffdfbeaf1c8002f0831d"],["img/logo.JPG","c0f8e42bd8fcc259c76e6628db119dc9"],["img/logo.png","7b0d0be5c71199b344ef59685fd98a52"],["img/logo1.png","7131724cc2a2050de09c7ecfb0a862de"],["img/stackWhite.svg","8f7e8610c7ccd5597b266b44339d23bc"],["img/successCloudNew.svg","965dfc6f8df7f52cf5cf5b87be6d4c91"],["img/tweetThis.svg","da9befbed46a3f9e9e14328cb20cbcea"],["img/workoutHome.jpg","4a85720962671c5bb5263f4f1e83e7b0"],["index.html","aec5a5a19c36cbd39f961b8a186f42c6"],["index.php","5dc171cbf09b5cd8831708e468f79932"],["kindnessMed.php","c8ac757bcca9bae399cc8ff18d0ee6b2"],["manifest.json","3332f87fd5be098f734e01b68e1ff2fe"],["mindfulnessPractice.php","51ff1c3fa9782e5221a28a8c12c549b6"],["monSchedule.php","60e1ba20fbc63a6c1c1e418b100b1cdb"],["mondaySchedule.php","4cf5e24edc84f02208dfab40baa9050e"],["recipes1.php","7a89741c370643ec34a1534003249c03"],["recipes2.php","72d64e5571ffee3241a95c4352d6f502"],["recipes3.php","c83f6fca61b5ea0a027b8318304c7550"],["recipes4.php","40b1e731060d0eee183939dff3135b41"],["recipesHome.php","cacca5454739e4470fc2d6f0c3796fee"],["scheduleEnter.php","ab49605f51dba645f23a4dd662f2cb1d"],["stretchBreak.php","64548c312a72d009cd8d4130b90439a0"],["submitting.php","ba8f2cf561e2df5344b3a2282a4158ca"],["sw.js","dbe44e94430beddb08e9e19ca114ed5f"],["toastr/CHANGELOG.md","9f12574e997b999bbcff791154b3ff2e"],["toastr/README.md","879ef69e8754d4fc3591917095355432"],["toastr/build/toastr.css","6dd68d17e33a0641e9d576fd0e7b2827"],["toastr/build/toastr.js.map","c9facbe25b5615323a7dad4a9de63653"],["toastr/build/toastr.min.css","f284028c678041d687c6f1be6968f68a"],["toastr/build/toastr.min.js","8ee1218b09fb02d43fcf0b84e30637ad"],["toastr/demo.html","c7d8e7c28147229473a4409d6df81107"],["toastr/gulpfile.js","1167093d0eb1685a7ce5e59ebbd8445d"],["toastr/karma.conf.js","99db6d60317cff291cbb9a552123f22b"],["toastr/nuget/content/content/toastr.css","207f67872d7e9302b3b36fc66c34462d"],["toastr/nuget/content/content/toastr.less","ece6dacbb5c496bccdaffa202fc918c6"],["toastr/nuget/content/content/toastr.min.css","7ddc0ff9437d0e9caf5364931a5de921"],["toastr/nuget/content/content/toastr.scss","27f1804a9ef5517a5b1456ba40daec41"],["toastr/nuget/content/scripts/toastr.js","78bc479a96133f5a7ef9cc2b329a607e"],["toastr/nuget/content/scripts/toastr.min.js","d96f460350fd7beb5e2ecf934897a695"],["toastr/nuget/content/scripts/toastr.min.js.map","555acca0e782eb9fe5d0881b2d35ee25"],["toastr/nuget/toastr.1.0.0.nupkg","e0e41e6757d6653b636ad5e9bb60aee5"],["toastr/nuget/toastr.1.0.0.nuspec","8d428b6d24370842402c135b86a96942"],["toastr/nuget/toastr.1.0.1.nupkg","b1a0b163a865d7ea2d1e5805619bb584"],["toastr/nuget/toastr.1.0.1.nuspec","876a618e6f598e1b48b218b6e4e22293"],["toastr/nuget/toastr.1.0.2.nupkg","37793e98a105bffbaae4d3be501a2317"],["toastr/nuget/toastr.1.0.2.nuspec","89224dbc1ff5c003c7d1b387b209c39e"],["toastr/nuget/toastr.1.0.3.nupkg","bcebe839708935be6131f97abc66554b"],["toastr/nuget/toastr.1.0.3.nuspec","fc1c67fe2c73497bfefb969983027d19"],["toastr/nuget/toastr.1.1.0.nupkg","7dae8a2c6f733e3f3bcad4c9e3439cc3"],["toastr/nuget/toastr.1.1.0.nuspec","b3a02ee2c8cb2cacbf07c7b9d080e838"],["toastr/nuget/toastr.1.1.1.nupkg","2213cbb0738f0fc8b70a098670cb16a4"],["toastr/nuget/toastr.1.1.1.nuspec","31dbc4f3e23955bf22bf82aab73f505d"],["toastr/nuget/toastr.1.1.2.nupkg","3fe51f8dd9e24a66ba045a99e254b169"],["toastr/nuget/toastr.1.1.2.nuspec","cb2ab02153736a13815a323b2a230423"],["toastr/nuget/toastr.1.1.3.nupkg","cd3cee78505f60a97885dbef11cbb5fa"],["toastr/nuget/toastr.1.1.4.1.nupkg","739cf8bfe9c02603d59d7da2fda46841"],["toastr/nuget/toastr.1.1.4.1.nuspec","2ef6bb1dbfc1bf1bb08485a07ee13d0e"],["toastr/nuget/toastr.1.1.4.2.nupkg","5c693dc117e6eaf3fab10f586688ecc1"],["toastr/nuget/toastr.1.1.4.2.nuspec","33bfae58a24d38e917d2d08a97e34b3e"],["toastr/nuget/toastr.1.1.4.nupkg","c4a753df23e282e05c46bc752c9c74da"],["toastr/nuget/toastr.1.1.4.nuspec","85a6b3c1c1f08744c6ef1e862439172c"],["toastr/nuget/toastr.1.1.5.nupkg","51168bf809df74482fc04dc8820c8678"],["toastr/nuget/toastr.1.1.5.nuspec","eba4d089a44c249e42d9c019ad5e5ef3"],["toastr/nuget/toastr.1.2.0.nupkg","870d7bb77ef2962ae2a73d58021b8c87"],["toastr/nuget/toastr.1.2.0.nuspec","3ac54e5cafe41920c964298df928c545"],["toastr/nuget/toastr.1.2.1.nupkg","18d5ab3c7e1c744cde7945f33b3aae78"],["toastr/nuget/toastr.1.2.1.nuspec","3a9bd23f36e7cff0613e85a3bf2712a5"],["toastr/nuget/toastr.1.2.2.nupkg","aa2943c6521540e0c2cf3ed991b0093b"],["toastr/nuget/toastr.1.2.2.nuspec","e9636fa00402552b4cf814fb144eece0"],["toastr/nuget/toastr.1.3.0.nupkg","4e7dc0c628bd95c2b4a206c05087cce5"],["toastr/nuget/toastr.1.3.0.nuspec","21f46147fbc002195247aab9895263f4"],["toastr/nuget/toastr.1.3.1.nupkg","88a862ba0c5c9ae3cfbcf109fc3d5aad"],["toastr/nuget/toastr.1.3.1.nuspec","0e1b31b3f86800af098d1fb0a30206dd"],["toastr/nuget/toastr.2.0.0-rc1.nupkg","13722f02cb277fe1cfb8df86752adfa6"],["toastr/nuget/toastr.2.0.0-rc1.nuspec","4f377b0f31242a7a9e636b12c64dcda4"],["toastr/nuget/toastr.2.0.1.nupkg","d26e133b684b7e3d154ba7f935da162f"],["toastr/nuget/toastr.2.0.1.nuspec","d5169fbf19e392455418b6bf27b1c3ed"],["toastr/nuget/toastr.2.0.2.nupkg","21850335aa5a0c5643d30b458e32390c"],["toastr/nuget/toastr.2.0.2.nuspec","16aa101eb3f913fb95ebef48d8b715f7"],["toastr/nuget/toastr.2.0.3.nupkg","343ed82827a1f04404dfd3682dafe856"],["toastr/nuget/toastr.2.0.3.nuspec","fc336f3703aa7740db5af8f0ac8311a9"],["toastr/package-lock.json","1bcb3fa5f1b347aa487f3da7819da5dd"],["toastr/package.json","2bc271c38c1cb7c6ffea3f5c4a105808"],["toastr/release checklist.md","47b84b1730385e32053f4d484990bcf9"],["toastr/tests/qunit/qunit.css","c15fa7139c3c5957fc1dfa9d0bc6f73e"],["toastr/tests/qunit/qunit.js","46ae093abae9b60498853a8b89cb1d3c"],["toastr/tests/toastr-tests.html","e399b09bd7be18fcb417bf09a80c38b5"],["toastr/tests/unit/qunit-helper.js","95cb0906b69c8183e58cd6e1139dea14"],["toastr/tests/unit/toastr-tests.js","27caae49f060ebb06b875919e97a9589"],["toastr/tests/unit/x.js","fe212318eec716746cd584fd41dea649"],["toastr/toastr-icon.png","befa0250f77e8e3541123e92c2a0ad76"],["toastr/toastr.js","ab180bcdd08afe86768c6b8105bf9df2"],["toastr/toastr.less","789c0178fa0cafa4ca54d60d52f5d55b"],["toastr/toastr.scss","e0056cdab354a2a410b5bdc526b1e2ea"],["walkYourWay.php","e5e2a46a3dc563097653ec41f52426eb"],["wholeBody.php","7acb005b6d0a080a6efae0e29a98f4dc"],["workoutHome.css","3b99ffbcc547d19f0322795476c0c498"],["workoutHome.jpg","4a85720962671c5bb5263f4f1e83e7b0"],["workoutHome.php","1522663001092d005ae449832aea0451"]];
var cacheName = 'sw-precache-v3-sw-precache-' + (self.registration ? self.registration.scope : '');


var ignoreUrlParametersMatching = [/^utm_/];



var addDirectoryIndex = function(originalUrl, index) {
    var url = new URL(originalUrl);
    if (url.pathname.slice(-1) === '/') {
      url.pathname += index;
    }
    return url.toString();
  };

var cleanResponse = function(originalResponse) {
    // If this is not a redirected response, then we don't have to do anything.
    if (!originalResponse.redirected) {
      return Promise.resolve(originalResponse);
    }

    // Firefox 50 and below doesn't support the Response.body stream, so we may
    // need to read the entire body to memory as a Blob.
    var bodyPromise = 'body' in originalResponse ?
      Promise.resolve(originalResponse.body) :
      originalResponse.blob();

    return bodyPromise.then(function(body) {
      // new Response() is happy when passed either a stream or a Blob.
      return new Response(body, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText
      });
    });
  };

var createCacheKey = function(originalUrl, paramName, paramValue,
                           dontCacheBustUrlsMatching) {
    // Create a new URL object to avoid modifying originalUrl.
    var url = new URL(originalUrl);

    // If dontCacheBustUrlsMatching is not set, or if we don't have a match,
    // then add in the extra cache-busting URL parameter.
    if (!dontCacheBustUrlsMatching ||
        !(url.pathname.match(dontCacheBustUrlsMatching))) {
      url.search += (url.search ? '&' : '') +
        encodeURIComponent(paramName) + '=' + encodeURIComponent(paramValue);
    }

    return url.toString();
  };

var isPathWhitelisted = function(whitelist, absoluteUrlString) {
    // If the whitelist is empty, then consider all URLs to be whitelisted.
    if (whitelist.length === 0) {
      return true;
    }

    // Otherwise compare each path regex to the path of the URL passed in.
    var path = (new URL(absoluteUrlString)).pathname;
    return whitelist.some(function(whitelistedPathRegex) {
      return path.match(whitelistedPathRegex);
    });
  };

var stripIgnoredUrlParameters = function(originalUrl,
    ignoreUrlParametersMatching) {
    var url = new URL(originalUrl);
    // Remove the hash; see https://github.com/GoogleChrome/sw-precache/issues/290
    url.hash = '';

    url.search = url.search.slice(1) // Exclude initial '?'
      .split('&') // Split into an array of 'key=value' strings
      .map(function(kv) {
        return kv.split('='); // Split each 'key=value' string into a [key, value] array
      })
      .filter(function(kv) {
        return ignoreUrlParametersMatching.every(function(ignoredRegex) {
          return !ignoredRegex.test(kv[0]); // Return true iff the key doesn't match any of the regexes.
        });
      })
      .map(function(kv) {
        return kv.join('='); // Join each [key, value] array into a 'key=value' string
      })
      .join('&'); // Join the array of 'key=value' strings into a string with '&' in between each

    return url.toString();
  };


var hashParamName = '_sw-precache';
var urlsToCacheKeys = new Map(
  precacheConfig.map(function(item) {
    var relativeUrl = item[0];
    var hash = item[1];
    var absoluteUrl = new URL(relativeUrl, self.location);
    var cacheKey = createCacheKey(absoluteUrl, hashParamName, hash, false);
    return [absoluteUrl.toString(), cacheKey];
  })
);

function setOfCachedUrls(cache) {
  return cache.keys().then(function(requests) {
    return requests.map(function(request) {
      return request.url;
    });
  }).then(function(urls) {
    return new Set(urls);
  });
}

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return setOfCachedUrls(cache).then(function(cachedUrls) {
        return Promise.all(
          Array.from(urlsToCacheKeys.values()).map(function(cacheKey) {
            // If we don't have a key matching url in the cache already, add it.
            if (!cachedUrls.has(cacheKey)) {
              var request = new Request(cacheKey, {credentials: 'same-origin'});
              return fetch(request).then(function(response) {
                // Bail out of installation unless we get back a 200 OK for
                // every request.
                if (!response.ok) {
                  throw new Error('Request for ' + cacheKey + ' returned a ' +
                    'response with status ' + response.status);
                }

                return cleanResponse(response).then(function(responseToCache) {
                  return cache.put(cacheKey, responseToCache);
                });
              });
            }
          })
        );
      });
    }).then(function() {
      
      // Force the SW to transition from installing -> active state
      return self.skipWaiting();
      
    })
  );
});

self.addEventListener('activate', function(event) {
  var setOfExpectedUrls = new Set(urlsToCacheKeys.values());

  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return cache.keys().then(function(existingRequests) {
        return Promise.all(
          existingRequests.map(function(existingRequest) {
            if (!setOfExpectedUrls.has(existingRequest.url)) {
              return cache.delete(existingRequest);
            }
          })
        );
      });
    }).then(function() {
      
      return self.clients.claim();
      
    })
  );
});


self.addEventListener('fetch', function(event) {
  if (event.request.method === 'GET') {
    // Should we call event.respondWith() inside this fetch event handler?
    // This needs to be determined synchronously, which will give other fetch
    // handlers a chance to handle the request if need be.
    var shouldRespond;

    // First, remove all the ignored parameters and hash fragment, and see if we
    // have that URL in our cache. If so, great! shouldRespond will be true.
    var url = stripIgnoredUrlParameters(event.request.url, ignoreUrlParametersMatching);
    shouldRespond = urlsToCacheKeys.has(url);

    // If shouldRespond is false, check again, this time with 'index.html'
    // (or whatever the directoryIndex option is set to) at the end.
    var directoryIndex = 'index.html';
    if (!shouldRespond && directoryIndex) {
      url = addDirectoryIndex(url, directoryIndex);
      shouldRespond = urlsToCacheKeys.has(url);
    }

    // If shouldRespond is still false, check to see if this is a navigation
    // request, and if so, whether the URL matches navigateFallbackWhitelist.
    var navigateFallback = '';
    if (!shouldRespond &&
        navigateFallback &&
        (event.request.mode === 'navigate') &&
        isPathWhitelisted([], event.request.url)) {
      url = new URL(navigateFallback, self.location).toString();
      shouldRespond = urlsToCacheKeys.has(url);
    }

    // If shouldRespond was set to true at any point, then call
    // event.respondWith(), using the appropriate cache key.
    if (shouldRespond) {
      event.respondWith(
        caches.open(cacheName).then(function(cache) {
          return cache.match(urlsToCacheKeys.get(url)).then(function(response) {
            if (response) {
              return response;
            }
            throw Error('The cached response that was expected is missing.');
          });
        }).catch(function(e) {
          // Fall back to just fetch()ing the request if some unexpected error
          // prevented the cached response from being valid.
          console.warn('Couldn\'t serve response for "%s" from cache: %O', event.request.url, e);
          return fetch(event.request);
        })
      );
    }
  }
});







