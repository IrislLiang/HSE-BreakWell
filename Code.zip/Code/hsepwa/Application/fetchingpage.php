<?php
    // call connection 

    define('DB_SERVER', '81.16.28.205');
    define('DB_USERNAME', 'u984442499_hsedbadmin');
    define('DB_PASSWORD', 'Jeremiah.123');
    define('DB_NAME', 'u984442499_hse_database');

    /* Attempt to connect to MySQL database */
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    $weekday = 4; //hardcoded for prototype
    $user_id = 1; //hardcoded for prototype

    $query = "SELECT * FROM events WHERE userId=1";

    $success = $conn->query($query);

    if ($success->num_rows > 0) { 
        // create a session variable called 'logged_in' to store username
        $_SESSION['logged_in'] = $username;
         // if successful send to enter schedule page
         header( 'Location: editSchedule.php' );
         }else{
         // if unsuccessful redirect back to log in
         header( 'Location: scheduleEnter.php' );
          }

?>