<?php

// call connection 

define('DB_SERVER', '81.16.28.205');
define('DB_USERNAME', 'u984442499_hsedbadmin');
define('DB_PASSWORD', 'Jeremiah.123');
define('DB_NAME', 'u984442499_hse_database');

/* Attempt to connect to MySQL database */
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

$weekday = 4; //hardcoded for prototype
$user_id = 1; //hardcoded for prototype

$monStart = $_POST['monStart'];
$monEnd = $_POST['monEnd'];

  // Insert form data into table
          $query = "UPDATE events
          SET eventStart= '$monStart', eventEnd = '$monEnd'

            WHERE (userId=1)"; //hardcoded for prototype

      $success = $conn->query($query);

      if (!$success) {    
        die("Couldn't enter data: ".$conn->error);
      }

    // redirect to registration submitted
     header('Location: editbreaks.php');

  // Close connection
  $conn->close();
   

?>
