<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="workoutHome.css"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="workoutHome.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">  
<style>
    .container {
  position: relative;
  overflow: hidden;
  width: 100%;
  padding-top: 56.25%; /* 16:9 Aspect Ratio (divide 9 by 16 = 0.5625) */
}

/* Then style the iframe to fit in the container div with full height and width */
.responsive-iframe {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
}
  </style>
  </head>
  <body>
     
<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a class="active" href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->

<div id="main">
  <header class="header-bar">
  <button class="openbtn" onclick="openNav()">☰</button>
  <span class="page-title">Workout Library</span>
</header><!-- header-bar -->
</div><!-- main -->

<div id="mySidebar" class="sidebar">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
  <a href="#">Weekly Schedule</a>
  <a href="#">Notifications</a>
  <a href="#">Account</a>
  <a href="#">Settings</a>
</div><!-- mySidebar sidebar -->


     <img src="LOGO.png" alt="hse logo" width="250" height="250" >
    <div class="custom-select" style="width:auto; position:absolute;right:30%;top:50px;float:right; ">
       <P style="font-size:200%;position:flex;flex-direction:row">
      Select Workout Type: 
    </P>
       <br>
  <select name = 'test' onchange = 'gotourl(this.value)' >\
    <option value="0">Select Workout:</option>
    <option value="2">Stretch Break</option>
    <option value="3">Desk Stretches</option>
    <option value="4">Breath & Body Mindfulness Practice</option>
    <option value="5">Three Minute Breathing Space</option>
    <option value="6">Loving Kindness Mediation</option>
    <option value="7">Strengthening Exercises for the Whole Body</option>
    <option value=8>Walk your way to Fitness</option>
    <option value=9>How to Stay Motivated</option>
  </select>
      
</div>  
   
   <h1>
     &#12288; Minding Yourself - Breath & Body Mindfulness Practice
    </h1><br>
    
    <iframe width="100%" src="https://www.youtube.com/embed/r2XeF1YU3sg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
    </iframe>

     <h2>
      &#12288;    Disclaimer:
    </h2>
     <p class="tips" style="padding-left:5%;padding-right:5%;font-size:70%">
     When joining me for this workout video, you need to take some precautions as your health and safety is the most important. To avoid any injury or harm, you need to check your health with your doctor before exercising. By performing any fitness exercises without supervision like with this video, you are performing them at your own risk. See a fitness professional to give you advice on your exercise form. Pamela Reif will not be responsible or liable for any injury or harm you sustain as a result of this video.
       
    </p>
  </body>
 <script>
function gotourl(id)
{
  if(id == 2)
{
location.href='stretchBreak.php';
}else if(id == 3)
{
location.href='deskStretches.php';
}else if(id == 4)
{
location.href='mindfulnessPractice.php';
}else if(id == 5)
{
location.href='breathingSpace.php';
}else if(id == 6)
{
location.href='kindnessMed.php';
}else if(id == 7)
{
location.href='wholeBody.php';
}else if(id == 8)
{
location.href='walkYourWay.php';
}else if(id == 9)
{
location.href='Motivated.php';
}
}

function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}

</script>
</html>