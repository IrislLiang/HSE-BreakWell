<!DOCTYPE html>
<html>
  <head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">  

<style>
#content {
    display: inline-block;
    text-align: left;
    background-color: #fff;
    font-family: 'Open Sans', sans-serif;
    padding: 20px;
    width: 80%;               /* fill up the entire div */
    margin-bottom: 70px;
}
</style>
  </head>

<body>
      
<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a class="active" href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->


  <div id="main">
    <header class="header-bar">
    <button class="openbtn" onclick="openNav()">☰</button>
    <span class="page-title">RECIPES</span>
    <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
  </header><!-- header-bar -->
</div><!-- main  -->

  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="EnterSchedule.php">edit weekly schedule</a>
    <a href="#">manage notifications</a>
    <a href="#">account settings</a>
  </div><!-- mySidebar sidebar -->
  
<div id="content" style="position:flex; flex-direction:row">
<h1 style="text-align:center">Healthy Pepperoni Pizza</h1>
  <h2 style="text-align:center"><i>Omit ham for vegetarian version</i></h2>
  <hr>
  <h2>Ingredients - Serves 2 Adults</h2>
    <p>
    <ul >
      <li>140g thin pizza base</li>
      <li>100g tomato sauce</li>
      <li>50g low fat mozzarella</li>
      <li>50g ham</li>
      <li>20g mushrooms</li>
      <li>20g peppers</li>
      <li>30g sweetcorn</li>
    </ul>
    </p>
     <h2>Method</h2>
    <p>
    <ol>
      <li>Pre-heat the oven to 200°C / 400°F / Gas Mark 6</li>
      <li>Cover the base with tomato sauce and add toppings of choice</li>
      <li>Bake in the pre-heated oven for around 20 minutes, or until the base is cooked with a golden colour</li>
    </ol>
    </p>
    <img src="dish3.png" alt="picture" height="500px" width="300px" style="padding-left:50px">
    </div>
  </body>
<script>
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>

</html>