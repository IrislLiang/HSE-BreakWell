<?php
session_start();

define('DB_SERVER', '81.16.28.205');
define('DB_USERNAME', 'u984442499_hsedbadmin');
define('DB_PASSWORD', 'Jeremiah.123');
define('DB_NAME', 'u984442499_hse_database');


$username = $_POST["username"];
$password = $_POST["password"]; 

require 'connection.php'; // call connection file
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME); // attribute connection to variable

  // Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
  
$query = "SELECT * FROM users WHERE user_Name='$username'AND user_Pass='$password'";
$result = $conn->query($query);

if ($result->num_rows > 0) { 
   // create a session variable called 'logged_in' to store username
   $_SESSION['logged_in'] = $username;
    // if successful send to enter schedule page
    header( 'Location: fetchingPage.php' );
    }else{
    // if unsuccessful redirect back to log in
    header( 'Location: Login.php' );
     }  

$conn->close();

//check if user is logged in
function isLoggedIn()
{
	if (isset($_SESSION['username'])) {
		return true;
	}else{
		return false;
	}
}

// return user array from their id
function getUserById($id){
	global $db;
	$query = "SELECT * FROM users WHERE user_id=" . $id;
	$result = mysqli_query($db, $query);

	$user = mysqli_fetch_assoc($result);
	return $user;
}

  ?>