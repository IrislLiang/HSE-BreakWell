<?php
  require 'connect.php'; 
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&family=Quicksand&display=swap" rel="stylesheet">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">
<style>
* {
  box-sizing: border-box;
}

body {
  background-color: #fff;
  font-family: 'Open Sans', sans-serif;
  overflow-x: hidden;
}

/* Center website */
.main {
  max-width: 1000px;
  margin: auto; 
  padding: 20px;
}

.row {
  margin: 8px -16px;
}

/* Add padding BETWEEN each column */
.row,
.row > .column {
  padding: 8px;
}

/* Create four equal columns that floats next to each other */
.column {
  float: left;
  width: 25%;
}

/* Clear floats after rows */ 
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Content */
.content {
  background-color: white;
  padding: 10px;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 900px) {
  .column {
    width: 50%;
  }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
</style>
</head>
<body>

  
<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a class="active" href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->


  <div id="main">
    <header class="header-bar">
    <button class="openbtn" onclick="openNav()">☰</button>
    <span class="page-title">RECIPES</span>
    <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
  </header><!-- header-bar -->
</div><!-- main  -->

  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="EnterSchedule.php">edit weekly schedule</a>
    <a href="#">manage notifications</a>
    <a href="#">account settings</a>
  </div><!-- mySidebar sidebar -->



<!-- MAIN (Center website) -->
<div class="main">

<h1 style="text-align:center">Eat Well, Live Well</h1>
<hr> 
<p style="text-align:center"> <i>Your body is your temple<br>
  keep it pure and clean for the soul to reside in.</i></p>

<!-- Portfolio Gallery Grid -->
<div class="row">
  <div class="column">
    <div class="content">
      <a href="recipes1.php">
        <img src="Spinachsalad240x185.jpg" alt="Spinach and mandarin salad" style="width:100%"></a>
      <h2>Spinach and Mandarin Salad</23>
      <p><i>A highly nutritious and versatile green, spinach can be served on its own or mixed with other ingredients to make a savoury entrée. </i></p>
    </div>
  </div>
  <div class="column">
    <div class="content">
      <a href="recipes2.php">
        <img src="Spice-Bag_1.jpg" alt="Spiced Chips" style="width:100%"></a>
      <h2>Spiced Chips</h2>
      <p><i>A low salt, low fat, low sugar alternative to a takeaway favourite! </i></p>
    </div>
  </div>
  <div class="column">
    <div class="content">
      <a href="recipes3.php">
        <img src="Pepperoni-Pizza_1.jpg" alt="Pizza" style="width:100%"></a>
      <h2>Pepperoni Pizza</h2>
      <p><i>A healthier recipe for pizza that will be ready in under half an hour. </i> </p>
    </div>
  </div>
  <div class="column">
    <div class="content">
      <a href="recipes4.php">
        <img src="Mexican-Bean-Burrito_1.jpg" alt="Burrito" style="width:100%"></a>
      <h2>Mexican Bean Burrito</h2>
      <p><i>This delicious alternative on a takeaway is sure to be a hit with the whole family. It is also suitable for vegetarians! </i></p>
    </div>
  </div>
<!-- END GRID -->
</div>


</div>
<script>
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>
</body>
</html>