<?php
include('connect.php');
$feedback_details;
	// connect to the database
	$con = mysqli_connect('81.16.28.205', 'u984442499_hsedbadmin', 'Jeremiah.123', 'u984442499_hse_database');

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="manifest" href="manifest.json">
<link rel="stylesheet" href="css/style.css">
<script src="jquery.min.js"></script>

<title>Feedback</title>
</head>
<style>

body{
  overflow-x: hidden;
}

#wrapper {
    max-width: 75%;
    margin-left: 10vw;    /* center the page */
    margin-bottom: 70px;
    font-family: 'Open Sans', sans-serif;
    overflow-x: hidden;
}

#content {
    display: inline-block;
    background-color: #fff;
    font-family: 'Open Sans', sans-serif;
    padding: 20px;
    text-align: left;
    width: 90%;                /* fill up the entire div */
}

/* begin table styles */
table {
    border-collapse: collapse;
    width: 100%;
}

table a {
    color: #000;
}

table a:hover {
    color:#373737;
    text-decoration: none;
}

th {
    background-color: #B40E1F;
    color: #F0F0F0;
}

td {
    padding: 5px;
}
</style>
<body>


<div class="icon-bar">
  <a href="dashboard.php"><i class="fa fa-home"></i></a>
  <a href="workouthome.php"><i class="fa fa-heartbeat"></i></a>
  <a href="recipeshome.php"><i class="material-icons">restaurant</i></a>
  <a class="active" href="feedback.php"><i class="fa fa-comments-o"></i></a>
</div><!-- icon-bar -->



  <div id="main">
    <header class="header-bar">
    <button class="openbtn" onclick="openNav()">☰</button>
    <span class="page-title">SUGGESTIONS</span>
    <img src="HSE_Logo_White_Small.png" style="float:right" width="50px" height="50px" alt="HSE Ireland">
  </header><!-- header-bar -->
</div><!-- main  -->

  <div id="mySidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="EnterSchedule.php">edit weekly schedule</a>
    <a href="#">manage notifications</a>
    <a href="#">account settings</a>
  </div><!-- mySidebar sidebar -->

  <div id="content">
  <h1>Your Voice Matters!</h1>
  <p>Wellbeing is your sense of physical, mental, emotional, social, financial, environmental, and occupational health. We want to know what wellbeing resources you want at work. Share your thoughts and like others recommendations so we can invest in the support you need and want.</p>
<div id="newContent">
<form  method="POST" action="feedback.php">
    <textarea class="input-group" aria-label="Share Your Feedback" type="text" id="new_feedback" name="new_feedback" style="max-width: 100%" placeholder="How can we better support your wellbeing?" method="POST"></textarea>
    <input type="submit" class="w3-btn" style="float:right; border:solid 1px; border-radius:2px; background-color:#00B0E0" name="submit" value="submit"></input>
</form>


<?php

$username = "u984442499_hsedbadmin";
$password = "Jeremiah.123";
$database = "u984442499_hse_database";
$mysqli = new mysqli("81.16.28.205", $username, $password, $database);

$feedback_details = $_POST['new_feedback'];
$user_id = 1; //hardcoded for prototype
$feedback_likes = 0; //hardcoded for prototype

if(isset($_POST['submit']))
            {
              if (!empty($feedback_details))
                {
                  $query = "INSERT INTO feedback (feedback_details, user_id, feedback_likes)
                  VALUES ('{$feedback_details}','{$user_id}','{$feedback_likes}')";


                  $mysqli->query($query);

                  header('location: feedback.php');

                  $mysqli -> close();

                }
            }

            unset($feedback_details);
?>

</div> <!-- new content -->
<br><br>

  <?php 

  
      	$feedback = mysqli_query($con, "SELECT * FROM feedback");
        while ($row = mysqli_fetch_array($feedback))

   { ?>

      <div id="content">
			<div class="feedback">
				<?php echo $row['feedback_details']; ?>
        <br><br>
        <div class="feedback-date" style="font-size: 6px!important">
        <?php echo $row['feedback_date']; ?>
        <br>
      </div>
				<div style="padding: 2px; margin-top: 5px;">
          <hr>
        <?php
					// determine if user has already liked this post
					$results = mysqli_query($conn, "SELECT * FROM likes WHERE user_id=1 AND feedback_id=".$row['feedback_id']."");
          if (mysqli_num_rows($results) == 1 ):
        ?>
          <!-- user already likes post -->
						<span class="unlike fa fa-thumbs-up" data-id="<?php echo $row['likes_id']; ?>"></span>
						<span class="like hide fa fa-thumbs-o-up" data-id="<?php echo $row['likes_id']; ?>"></span>
					<?php else: ?>
						<!-- user has not yet liked post -->
						<span class="like fa fa-thumbs-o-up" data-id="<?php echo $row['likes_id']; ?>"></span>
						<span class="unlike hide fa fa-thumbs-up" data-id="<?php echo $row['likes_id']; ?>"></span>
					<?php endif ?>
            <span class="likes_count"><?php echo $row['feedback_likes']; ?> likes</span>
          <br>
				</div>
			</div>
    </div><!-- content -->
  <br><br>
	<?php }  ?>
</div><!-- wrapper -->

<script>
function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}

if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}


/*

  The like button

	$(document).ready(function(){
		// when the user clicks on like
		$('.like').on('click', function(){
			var feedback_id = $(this).data('feedback_id');
			    $post = $(this);

			$.ajax({
				url: './feedback.php',
				type: 'post',
				data: {
					'liked': 1,
					'feedback_id': feedback_id
				},
				success: function(response){
					$feedback.parent().find('span.likes_count').text(response + " likes");
					$feedback.addClass('hide');
					$feedback.siblings().removeClass('hide');
				}
			});
		});

		// when the user clicks on unlike
		$('.unlike').on('click', function(){
			var feedback_id = $(this).data('feedback_id');
		    $post = $(this);

			$.ajax({
				url: 'index.php',
				type: 'post',
				data: {
					'unliked': 1,
					'feedback_id': feedback_id
				},
				success: function(response){
					$post.parent().find('span.likes_count').text(response + " likes");
					$post.addClass('hide');
					$post.siblings().removeClass('hide');
				}
			});
		});
	});

*/
</script>

</body>
</html>
